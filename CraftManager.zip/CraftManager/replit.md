# Craft Management Application

## Overview
A Flask web application for managing craft projects with full CRUD operations and detailed reporting capabilities.

## Features
- Create, read, update, and delete craft items
- Track craft details: name, category, materials, difficulty level, completion status, and instructions
- Search and filter crafts by category and status
- Reports dashboard with statistics and visual charts
- Craft distribution by category and difficulty
- Completion rate tracking

## Tech Stack
- Backend: Flask, SQLAlchemy
- Database: SQLite
- Frontend: Bootstrap 5, Chart.js
- Forms: Flask-WTF

## Project Structure
- `app.py` - Main Flask application
- `models.py` - Database models
- `templates/` - HTML templates
- `static/` - CSS, JS, and assets
- `instance/` - SQLite database

## Recent Changes
- 2025-11-03: Initial project setup
