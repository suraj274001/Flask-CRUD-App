from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from models import db, Craft
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SelectField
from wtforms.validators import DataRequired
import os
from sqlalchemy import func

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SESSION_SECRET', 'dev-secret-key-please-change')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///crafts.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

class CraftForm(FlaskForm):
    name = StringField('Craft Name', validators=[DataRequired()])
    category = SelectField('Category', choices=[
        ('Knitting', 'Knitting'),
        ('Painting', 'Painting'),
        ('Woodworking', 'Woodworking'),
        ('Sewing', 'Sewing'),
        ('Jewelry', 'Jewelry'),
        ('Paper Crafts', 'Paper Crafts'),
        ('Other', 'Other')
    ], validators=[DataRequired()])
    materials = TextAreaField('Materials', validators=[DataRequired()])
    difficulty = SelectField('Difficulty', choices=[
        ('Beginner', 'Beginner'),
        ('Intermediate', 'Intermediate'),
        ('Advanced', 'Advanced')
    ], validators=[DataRequired()])
    status = SelectField('Status', choices=[
        ('Not Started', 'Not Started'),
        ('In Progress', 'In Progress'),
        ('Completed', 'Completed')
    ], validators=[DataRequired()])
    instructions = TextAreaField('Instructions')

@app.route('/')
def index():
    search_query = request.args.get('search', '')
    category_filter = request.args.get('category', '')
    status_filter = request.args.get('status', '')
    
    query = Craft.query
    
    if search_query:
        query = query.filter(Craft.name.ilike(f'%{search_query}%'))
    if category_filter:
        query = query.filter_by(category=category_filter)
    if status_filter:
        query = query.filter_by(status=status_filter)
    
    crafts = query.order_by(Craft.created_at.desc()).all()
    
    categories = ['Knitting', 'Painting', 'Woodworking', 'Sewing', 'Jewelry', 'Paper Crafts', 'Other']
    statuses = ['Not Started', 'In Progress', 'Completed']
    
    return render_template('index.html', crafts=crafts, categories=categories, 
                         statuses=statuses, search_query=search_query,
                         category_filter=category_filter, status_filter=status_filter)

@app.route('/craft/new', methods=['GET', 'POST'])
def new_craft():
    form = CraftForm()
    if form.validate_on_submit():
        craft = Craft(
            name=form.name.data,
            category=form.category.data,
            materials=form.materials.data,
            difficulty=form.difficulty.data,
            status=form.status.data,
            instructions=form.instructions.data
        )
        db.session.add(craft)
        db.session.commit()
        flash('Craft created successfully!', 'success')
        return redirect(url_for('index'))
    return render_template('craft_form.html', form=form, title='New Craft')

@app.route('/craft/<int:id>')
def view_craft(id):
    craft = Craft.query.get_or_404(id)
    return render_template('craft_detail.html', craft=craft)

@app.route('/craft/<int:id>/edit', methods=['GET', 'POST'])
def edit_craft(id):
    craft = Craft.query.get_or_404(id)
    form = CraftForm(obj=craft)
    
    if form.validate_on_submit():
        craft.name = form.name.data
        craft.category = form.category.data
        craft.materials = form.materials.data
        craft.difficulty = form.difficulty.data
        craft.status = form.status.data
        craft.instructions = form.instructions.data
        db.session.commit()
        flash('Craft updated successfully!', 'success')
        return redirect(url_for('view_craft', id=craft.id))
    
    return render_template('craft_form.html', form=form, title='Edit Craft', craft=craft)

@app.route('/craft/<int:id>/delete', methods=['POST'])
def delete_craft(id):
    craft = Craft.query.get_or_404(id)
    db.session.delete(craft)
    db.session.commit()
    flash('Craft deleted successfully!', 'success')
    return redirect(url_for('index'))

@app.route('/reports')
def reports():
    total_crafts = Craft.query.count()
    
    by_category = db.session.query(
        Craft.category, func.count(Craft.id)
    ).group_by(Craft.category).all()
    
    by_difficulty = db.session.query(
        Craft.difficulty, func.count(Craft.id)
    ).group_by(Craft.difficulty).all()
    
    by_status = db.session.query(
        Craft.status, func.count(Craft.id)
    ).group_by(Craft.status).all()
    
    completed_count = Craft.query.filter_by(status='Completed').count()
    in_progress_count = Craft.query.filter_by(status='In Progress').count()
    not_started_count = Craft.query.filter_by(status='Not Started').count()
    
    completion_rate = (completed_count / total_crafts * 100) if total_crafts > 0 else 0
    
    return render_template('reports.html',
                         total_crafts=total_crafts,
                         by_category=by_category,
                         by_difficulty=by_difficulty,
                         by_status=by_status,
                         completed_count=completed_count,
                         in_progress_count=in_progress_count,
                         not_started_count=not_started_count,
                         completion_rate=completion_rate)

@app.route('/api/reports/data')
def reports_data():
    by_category = db.session.query(
        Craft.category, func.count(Craft.id)
    ).group_by(Craft.category).all()
    
    by_difficulty = db.session.query(
        Craft.difficulty, func.count(Craft.id)
    ).group_by(Craft.difficulty).all()
    
    by_status = db.session.query(
        Craft.status, func.count(Craft.id)
    ).group_by(Craft.status).all()
    
    return jsonify({
        'categories': {cat: count for cat, count in by_category},
        'difficulties': {diff: count for diff, count in by_difficulty},
        'statuses': {status: count for status, count in by_status}
    })

with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
